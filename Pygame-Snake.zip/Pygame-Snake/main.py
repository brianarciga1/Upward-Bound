import pygame
import sys
import os
import random

pygame.init()

# --- Constants ---
WIDTH, HEIGHT = 800, 600
TILE_SIZE = 20
FPS = 10

# --- Screen Setup ---
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Multiplayer Snake")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 24)

# --- Load Assets ---
def load_image(name, size=(TILE_SIZE, TILE_SIZE)):
    return pygame.transform.scale(pygame.image.load(os.path.join("assets", name)), size)

images = {
    "player1": load_image("player1.png"),
    "player2": load_image("player2.png"),
    "coin": load_image("coin.png", (TILE_SIZE, TILE_SIZE)),
    "background": pygame.transform.scale(pygame.image.load(os.path.join("assets", "background.jpg")), (WIDTH, HEIGHT))
}

# --- Snake Class ---
class Snake:
    def __init__(self, x, y, image, controls):
        self.body = [(x, y)]
        self.direction = (1, 0)
        self.image = image
        self.controls = controls
        self.grow = False
        self.alive = True
        self.score = 0

    def update(self):
        if not self.alive:
            return

        keys = pygame.key.get_pressed()
        if keys[self.controls["up"]] and self.direction != (0, 1):
            self.direction = (0, -1)
        elif keys[self.controls["down"]] and self.direction != (0, -1):
            self.direction = (0, 1)
        elif keys[self.controls["left"]] and self.direction != (1, 0):
            self.direction = (-1, 0)
        elif keys[self.controls["right"]] and self.direction != (-1, 0):
            self.direction = (1, 0)

        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = (head_x + dx * TILE_SIZE, head_y + dy * TILE_SIZE)

        # Collision with self or wall
        if (new_head in self.body or
            new_head[0] < 0 or new_head[0] >= WIDTH or
            new_head[1] < 0 or new_head[1] >= HEIGHT):
            self.alive = False
            return

        self.body.insert(0, new_head)
        if not self.grow:
            self.body.pop()
        else:
            self.grow = False

    def draw(self):
        for segment in self.body:
            screen.blit(self.image, segment)

    def eat(self, food_pos):
        if self.body[0] == food_pos:
            self.grow = True
            self.score += 1
            return True
        return False

# --- Food Spawner ---
def spawn_food(snakes):
    while True:
        x = random.randint(0, (WIDTH - TILE_SIZE) // TILE_SIZE) * TILE_SIZE
        y = random.randint(0, (HEIGHT - TILE_SIZE) // TILE_SIZE) * TILE_SIZE
        if all((x, y) not in snake.body for snake in snakes):
            return (x, y)

# --- Initialize Players ---
p1 = Snake(200, 300, images["player1"], {
    "up": pygame.K_w, "down": pygame.K_s, "left": pygame.K_a, "right": pygame.K_d
})
p2 = Snake(600, 300, images["player2"], {
    "up": pygame.K_UP, "down": pygame.K_DOWN, "left": pygame.K_LEFT, "right": pygame.K_RIGHT
})
snakes = [p1, p2]
food = spawn_food(snakes)

# --- Game Loop ---
running = True
game_over = False

while running:
    clock.tick(FPS)
    screen.blit(images["background"], (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if game_over and event.type == pygame.KEYDOWN and event.key == pygame.K_r:
            # Reset game
            p1 = Snake(200, 300, images["player1"], p1.controls)
            p2 = Snake(600, 300, images["player2"], p2.controls)
            snakes = [p1, p2]
            food = spawn_food(snakes)
            game_over = False

    if not game_over:
        # Update movement
        for snake in snakes:
            snake.update()

        # Eat food
        for snake in snakes:
            if snake.eat(food):
                food = spawn_food(snakes)

        # Snake-vs-snake collision
        if p1.alive and p1.body[0] in p2.body:
            p1.alive = False
        if p2.alive and p2.body[0] in p1.body:
            p2.alive = False

        # Check game over
        if not any(snake.alive for snake in snakes):
            game_over = True

        # Draw
        for snake in snakes:
            if snake.alive:
                snake.draw()
        screen.blit(images["coin"], food)
        screen.blit(font.render(f"P1: {p1.score}  P2: {p2.score}", True, (255, 255, 255)), (20, 20))
    else:
        game_over_text = font.render("Game Over! Press R to Restart", True, (255, 0, 0))
        screen.blit(game_over_text, (WIDTH // 2 - 180, HEIGHT // 2))

    pygame.display.flip()

pygame.quit()
sys.exit()
